#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "parser.h"
#include "debug.h"

static int convert_port(const char *str,ushort *port)
{
	int i = 1;
	ushort sum = 0;
	ushort temp;

	while(str[i]){
		if(str[i] >= '0' && str[i] <= '9'){
			temp = str[i] - '0';
			sum = sum * 10 + temp;
		}
		else{
			ERROR("str port number illegal!\n");
			return -1;
		}
		i++;
	}

	*port = sum;
	return 0;
}

int parser_url(const char *url,char *hostname,char *filename,ushort *port)
{
	char *tmp;
	char *flags;
	int ret;
	
	if(url == NULL){
		ERROR("input url is null!\n");
		return -1;
	}

	tmp = strstr(url,"http://");
	if(tmp == NULL){
		ERROR("url not http:// header!\n");
		return -1;
	}
	url += 7;

	tmp = strstr(url,"/");
	if(tmp == NULL){
		ERROR("url not filename");
		return -1;
	}
	snprintf(hostname,tmp-url+1,"%s",url);
	url = tmp;

	if( (flags = strstr(hostname,":")) != NULL ){
		ret = convert_port(flags,port);
		if(ret == -1){
			ERROR("url assign port error,using default port!\n");
			*port = 80;
		}
		flags[0] = 0;
	}
	else{
		*port = 80;
	}

	snprintf(filename,MAX_URL_FILENAME,"%s",url);
	
	return 0;
}

